﻿using System;
using System.Numerics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumpyDotNet;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using NumpyLib;

namespace NumpyDotNetTests
{
    [TestClass]
    public class HistogramTests : TestBaseClass
    {
        [Ignore]
        [TestMethod]
        public void xxx_Test_Histogram_Placeholder()
        {
        }

        #region Histograms

#if NOT_PLANNING_TODO

        [Ignore]
        [TestMethod]
        public void test_histogram_1()
        {

        }

        [Ignore]
        [TestMethod]
        public void test_histogram2d_1()
        {

        }

        [Ignore]
        [TestMethod]
        public void test_histogramdd_1()
        {

        }

        [Ignore]
        [TestMethod]
        public void test_bincount_1()
        {

        }

        [Ignore]
        [TestMethod]
        public void histogram_bin_edges_1()
        {

        }

        [Ignore]
        [TestMethod]
        public void digitize_1()
        {

        }
#endif
#endregion


    }
}
