﻿using System;
using System.Numerics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumpyDotNet;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using NumpyLib;

namespace NumpyDotNetTests
{
    [TestClass]
    public class StringOperationsTests : TestBaseClass
    {
        #if NOT_PLANNING_TODO
        [Ignore]
        [TestMethod]
        public void xxx_Test_StringOperations_Placeholder()
        {
        }
        #endif
    }
}
