﻿using System;
using System.Numerics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumpyDotNet;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using NumpyLib;

namespace NumpyDotNetTests
{
    [TestClass]
    public class NOT_PLANNING_TODO_Tests : TestBaseClass
    {
        [Ignore]
        [TestMethod]
        public void xxx_Test_NOTPLANNINGTODO_Placeholder()
        {
            // look for functions with NOT_PLANNING_TODO
        }


        [Ignore]
        [TestMethod]
        public void xxx_spacing_Placeholder()
        {
        }



    }
}
